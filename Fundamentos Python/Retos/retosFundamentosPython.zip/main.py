
'''
    --------------- MAIN --------------
    AUTOR: MARTÍN SAN JOSÉ DE VICENTE
    EMAIL: martin@imaginagroup.com
    AÑO: 2021
    REPOSITORIO GIT: https://gitlab.com/masajo/retos-python.git
    LICENCIA CÓDIGO: OSS

    * Descomenta los bloques para ejecutar cada uno de los retos y ver su funcionalidad
    * Los Retos están dividisos en dos carpetas (Básicos y Intermedios/Avanzados) con la intención
      de que los hagas en orden. Una vez hayas acabado con los Básicos pasa a los Intermedios/Avanzados.
    -----------------------------------
'''

'''
RETOS BÁSICOS
'''

# Reto 1 Básico
# from basicos.reto1 import reto1Basico
# reto1Basico()

# Reto 2 Básico
# from basicos.reto2 import reto2Basico
# reto2Basico()

# Reto 3 Básico
# from basicos.reto3 import reto3Basico
# reto3Basico()

# Reto 4 Básico
# from basicos.reto4 import reto4Basico
# reto4Basico()

# Reto 5 Básico
# from basicos.reto5 import reto5Basico
# reto5Basico()

# Reto 6 Básico
# from basicos.reto6 import reto6Basico
# reto6Basico()

# Reto 7 Básico
# from basicos.reto7 import reto7Basico
# reto7Basico()

# Reto 8 Básico
# from basicos.reto8 import reto8Basico
# reto8Basico()

# Reto 9 Básico
# from basicos.reto9 import reto9Basico
# reto9Basico()

# Reto 10 Básico
# from basicos.reto10 import reto10Basico
# reto10Basico()

# Reto 11 Básico
# from basicos.reto11 import reto11Basico
# reto11Basico()

# Reto 12 Básico
# from basicos.reto12 import reto12Basico
# reto12Basico()

# Reto 13 Básico
# from basicos.reto13 import reto13Basico
# reto13Basico()

# Reto 14 Básico
# from basicos.reto14 import reto14Basico
# reto14Basico()

# Reto 15 Básico
# from basicos.reto15 import reto15Basico
# reto15Basico()

# Reto 16 Básico
# from basicos.reto16 import reto16Basico
# reto16Basico()

# Reto 17 Básico
# from basicos.reto17 import reto17Basico
# reto17Basico()

# Reto 18 Básico
# from basicos.reto18 import reto18Basico
# reto18Basico()

'''
RETOS INTERMEDIOS AVANZADOS
'''

# Reto 1
# from intermediosAvanzados.reto1 import reto1Avanzado
# reto1Avanzado()

# Reto 2
# from intermediosAvanzados.reto2 import reto2Avanzado
# reto2Avanzado()

# Reto 3
# from intermediosAvanzados.reto3 import reto3Avanzado
# reto3Avanzado()

# Reto 4
# from intermediosAvanzados.reto4 import reto4Avanzado
# reto4Avanzado()

# Reto 5
# from intermediosAvanzados.reto5 import reto5Avanzado
# reto5Avanzado()

# Reto 6
# from intermediosAvanzados.reto6 import reto6Avanzado
# reto6Avanzado()

# Reto 7
# from intermediosAvanzados.reto7 import reto7Avanzado
# reto7Avanzado()

# Reto 8
# from intermediosAvanzados.reto8 import reto8Avanzado
# reto8Avanzado()

# Reto 9
# from intermediosAvanzados.reto9 import reto9Avanzado
# reto9Avanzado()

# Reto 10
# from intermediosAvanzados.reto10 import reto10Avanzado
# reto10Avanzado()

# Reto 11
# from intermediosAvanzados.reto11 import reto11Avanzado
# reto11Avanzado()

# Reto 12
# from intermediosAvanzados.reto15 import reto12Avanzado
# reto12Avanzado()

# Reto 13
# from intermediosAvanzados.reto13 import reto13Avanzado
# reto13Avanzado()

# Reto 14
# from intermediosAvanzados.reto14 import reto14Avanzado
# reto14Avanzado()

# Reto 15
# from intermediosAvanzados.reto15 import reto15Avanzado
# reto15Avanzado()

# Reto 16
# from intermediosAvanzados.reto16 import reto16Avanzado
# reto16Avanzado()

# Reto 17
# from intermediosAvanzados.reto17 import reto17Avanzado
# reto17Avanzado()

# Reto 18
# from intermediosAvanzados.reto18 import reto18Avanzado
# reto18Avanzado()

# Reto 19
# from intermediosAvanzados.reto19 import reto19Avanzado
# reto19Avanzado()

# Reto 20
# from intermediosAvanzados.reto20 import reto20Avanzado
# reto20Avanzado()

# Reto 21
# from intermediosAvanzados.reto21 import reto21Avanzado
# reto21Avanzado()

# Reto 22
# from intermediosAvanzados.reto22 import reto22Avanzado
# reto22Avanzado()

# Reto 23
# from intermediosAvanzados.reto23 import reto23Avanzado
# reto23Avanzado()

# Reto 24
# from intermediosAvanzados.reto24 import reto24Avanzado
# reto24Avanzado()

# Reto 25
# from intermediosAvanzados.reto25 import reto25Avanzado
# reto25Avanzado()

# Reto 26
from intermediosAvanzados.reto26 import reto26Avanzado
reto26Avanzado()

# Reto 27
# from intermediosAvanzados.reto27 import reto27Avanzado
# reto27Avanzado()

# Reto 28
# from intermediosAvanzados.reto28 import reto28Avanzado
# reto28Avanzado()

# Reto 29
# from intermediosAvanzados.reto29 import reto29Avanzado
# reto29Avanzado()

# Reto 30
# from intermediosAvanzados.reto30 import reto30Avanzado
# reto30Avanzado()